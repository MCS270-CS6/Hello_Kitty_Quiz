package com.example.hellokittyquiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.example.hellokittyquiz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import android.util.Log

private const val TAG = "MainActivity";

private val questionBank = listOf(Question(R.string.question1, true),
    Question(R.string.question2, false),
    Question(R.string.question3, false),
    Question(R.string.question4, false),
    Question(R.string.question5, true)
)
private var currentIndex = 0
private lateinit var true_button:Button
private lateinit var false_button: Button

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate(Bundle?) called")
        //setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        // hook up the button to its id
        //true_button = findViewById(R.id.true_button)
        //false_button = findViewById(R.id.false_button)

        // what happen if you click on those buttons
        binding.trueButton.setOnClickListener { view: View ->
            // Do something if you click on true button
            // have a correct toast that pops up
            checkAnswer(true, view)
        }

        binding.falseButton.setOnClickListener { view: View ->
            checkAnswer(false, view)
        }

        // onset listener for the next button
        // ie what happen if you press the next button
        binding.nextButton.setOnClickListener {
            currentIndex = (currentIndex + 1)%questionBank.size
            updateQuestion()
        }

        binding.previousButton.setOnClickListener {
            currentIndex = (currentIndex - 1)%questionBank.size
            updateQuestion()
        }

        binding.questionTextView.setOnClickListener {
            currentIndex = (currentIndex + 1)%questionBank.size
            updateQuestion()
        }

        // this will get you the id for the current question in the question bank
        updateQuestion()

    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart() is called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume is called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause is called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop is called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy is called")
    }

    private fun updateQuestion(){
        val questionTextResId = questionBank[currentIndex].textResId
        binding.questionTextView.setText(questionTextResId)
    }

    private fun checkAnswer(userAnswer:Boolean, view: View){

        val correctAnswer = questionBank[currentIndex].answer

        val messageResId = if (userAnswer == correctAnswer){
            R.string.correct_string
        }
        else{
            R.string.incorrect_string
        }
        //Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show()
        Snackbar.make(view, messageResId, Snackbar.LENGTH_SHORT).show()
    }
}